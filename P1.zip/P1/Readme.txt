Hi there, thanks for using my exploit
this is an exploit with a really friendly keysystem
after getting your key it will save for one week
for the next week you will need to get another key
if roblox updates you will have to get another key as well
ENJOY <3